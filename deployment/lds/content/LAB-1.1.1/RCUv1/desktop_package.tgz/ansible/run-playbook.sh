#!/bin/bash
#
# run-playbook.sh - Execute the Ansible playbook
#
# This script runs the main test-site-config.yml playbook to configure network devices.
#
# Usage:
#   ./run-playbook.sh                         # Normal execution (defaults)
#   ./run-playbook.sh -i custom.ini           # Custom inventory file
#   ./run-playbook.sh -p custom-playbook.yml  # Custom playbook file
#   ./run-playbook.sh -i inv.ini -p play.yml  # Custom inventory and playbook
#   ./run-playbook.sh --check                 # Dry run (check mode)
#   ./run-playbook.sh -i inv.ini -v           # Custom inventory with verbose
#   ./run-playbook.sh -v                      # Verbose output
#   ./run-playbook.sh -vv                     # More verbose
#   ./run-playbook.sh -vvv                    # Debug level
#

set -e  # Exit on error

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Default values
INVENTORY="inventory.ini"
PLAYBOOK="test-site-config.yml"

# Parse arguments for -i and -p options
ANSIBLE_ARGS=()
while [[ $# -gt 0 ]]; do
    case $1 in
        -i|--inventory)
            INVENTORY="$2"
            shift 2
            ;;
        -p|--playbook)
            PLAYBOOK="$2"
            shift 2
            ;;
        *)
            ANSIBLE_ARGS+=("$1")
            shift
            ;;
    esac
done

# Check if ansible-playbook is available
if ! command -v ansible-playbook &> /dev/null; then
    echo "[FAIL] Error: ansible-playbook command not found"
    echo "Please install Ansible first:"
    echo "  pip install ansible"
    exit 1
fi

# Check if inventory file exists
if [[ ! -f "$INVENTORY" ]]; then
    echo "[FAIL] Error: Inventory file not found: $INVENTORY"
    echo "Please ensure the inventory file exists in the script directory"
    exit 1
fi

# Check if playbook file exists
if [[ ! -f "$PLAYBOOK" ]]; then
    echo "[FAIL] Error: Playbook file not found: $PLAYBOOK"
    echo "Please ensure the playbook file exists in the script directory"
    exit 1
fi

echo "=========================================="
echo "Running Ansible Playbook"
echo "=========================================="
echo ""
echo "Playbook: $PLAYBOOK"
echo "Inventory: $INVENTORY"
echo "Arguments: ${ANSIBLE_ARGS[@]}"
echo ""

# Run the playbook with inventory and remaining arguments
ansible-playbook -i "$INVENTORY" "$PLAYBOOK" "${ANSIBLE_ARGS[@]}"

echo ""
echo "[PASS] Playbook execution complete!"
echo ""
