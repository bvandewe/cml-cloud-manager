#!/usr/bin/env python3
import yaml, argparse, sys, os
from netmiko import ConnectHandler

# TODO:
# Complete the missing router settings below:
# - OSPF process/area
# - Loopback0 mapping per router
# - NTP server


def load_inv(p):
    with open(p) as f:
        d = yaml.safe_load(f)
    return d["devices"], d["credentials"]


def cfg(c, lines):
    return c.send_config_set(lines)


def main():
    ap = argparse.ArgumentParser()
    script_dir = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument("-i", "--inventory", default=os.path.join(script_dir, "py_inventory.yaml"))
    a = ap.parse_args()
    devs, creds = load_inv(a.inventory)
    for name, info in devs.items():
        if not name.startswith("rtr"):
            continue
        try:
            with ConnectHandler(
                device_type=info.get("device_type", "cisco_ios"),
                host=info["host"],
                username=creds["username"],
                password=creds["password"],
                secret=creds["secret"],
            ) as c:
                c.enable()
                lb = LOOP[name]
                cmds = [
                    "interface Loopback0",
                    f"ip address {lb}",
                    "no shutdown",
                    "exit",
                    f"router ospf {OSPF['process']}",
                    # TODO:
                    # Fix the OSPF transit network statement below.
                    f"network 10.0.13.0 0.0.0.3 area {OSPF['area']}",
                    f"network {lb.split()[0]} 0.0.0.0 area {OSPF['area']}",
                    "exit",
                    f"ntp server {NTP}",
                ]
                cfg(c, cmds)
                print(f"[deploy] {name} ok")
        except Exception as e:
            print(f"[ERR] {name}: {e}", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
