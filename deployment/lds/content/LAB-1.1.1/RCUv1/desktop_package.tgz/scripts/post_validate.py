#!/usr/bin/env python3
import argparse
import os
import re
import sys
import time
import yaml
from netmiko import ConnectHandler


def load_inv(p):
    with open(p) as f:
        d = yaml.safe_load(f)
    return d["devices"], d["credentials"]


def ios(h, c):
    return ConnectHandler(
        device_type="cisco_ios",
        host=h,
        username=c["username"],
        password=c["password"],
        secret=c["secret"],
    )


def has(pattern, text, flags=0):
    return bool(re.search(pattern, text, flags))


def check(label, condition, failures):
    if not condition:
        failures.append(label)
    return condition


def main():
    ap = argparse.ArgumentParser()
    script_dir = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument("-i", "--inventory", default=os.path.join(script_dir, "py_inventory.yaml"))
    a = ap.parse_args()
    devs, creds = load_inv(a.inventory)
    vlan_id = int("80")
    vlan_name = f"LAB{vlan_id}"
    acl_name = "MGMT" + "OPS"
    base_host = devs["rtr01"]["host"] if "rtr01" in devs else next(iter(devs.values()))["host"]
    a_oct, b_oct, c_oct, _ = base_host.split(".")
    acl_permit = f"{a_oct}.{b_oct}.{c_oct}.0 0.0.0.255"
    ntp_server = f"{a_oct}.{b_oct}.{c_oct}.254"
    loop_ip = {"rtr01": "10.255.81.1", "rtr02": "10.255.81.2"}
    g01_desc = {"rtr01": "to-rtr02", "rtr02": "to-rtr01"}
    ospf_process = int("30")
    ospf_area = 0
    ospf_transit = "10.0.0.0 0.0.0.3"
    failures = []
    for sw in ["sw01", "sw02"]:
        try:
            with ios(devs[sw]["host"], creds) as c:
                c.enable()
                out = "\n" + c.send_command("show vlan brief")
                check(
                    f"{sw}: VLAN {vlan_id} named {vlan_name}",
                    has(rf"\n\s*{vlan_id}\s+{vlan_name}\b", out),
                    failures,
                )
        except Exception as e:
            failures.append(f"{sw}: validation error ({e})")
    for name in ["rtr01", "rtr02"]:
        try:
            with ios(devs[name]["host"], creds) as c:
                c.enable()
                loop0_out = c.send_command("show ip interface brief | i Loopback0")
                check(
                    f"{name}: Loopback0 {loop_ip[name]} is up/up",
                    has(rf"{re.escape(loop_ip[name])}.*up\s+up", loop0_out),
                    failures,
                )
                g01_out = c.send_command("show run interface GigabitEthernet0/1")
                check(
                    f"{name}: Gi0/1 description is {g01_desc[name]}",
                    has(rf"^\s*description {re.escape(g01_desc[name])}\s*$", g01_out, re.M),
                    failures,
                )
                acl_out = c.send_command("show run | section ip access-list standard")
                check(
                    f"{name}: ACL {acl_name} exists",
                    has(rf"^ip access-list standard {acl_name}\s*$", acl_out, re.M),
                    failures,
                )
                check(
                    f"{name}: ACL {acl_name} permit {acl_permit} exists",
                    has(rf"^\s*permit {re.escape(acl_permit)}\s*$", acl_out, re.M),
                    failures,
                )
                ospf_out = c.send_command("show run | section router ospf")
                check(
                    f"{name}: OSPF process is {ospf_process}",
                    has(rf"^router ospf {ospf_process}\s*$", ospf_out, re.M),
                    failures,
                )
                check(
                    f"{name}: OSPF transit network {ospf_transit} area {ospf_area}",
                    has(
                        rf"^\s*network {re.escape(ospf_transit)} area {ospf_area}\s*$",
                        ospf_out,
                        re.M,
                    ),
                    failures,
                )
                check(
                    f"{name}: OSPF loopback network {loop_ip[name]} area {ospf_area}",
                    has(
                        rf"^\s*network {re.escape(loop_ip[name])} 0.0.0.0 area {ospf_area}\s*$",
                        ospf_out,
                        re.M,
                    ),
                    failures,
                )
                ntp_out = c.send_command("show run | i ^ntp server")
                check(
                    f"{name}: NTP server {ntp_server}",
                    has(rf"^ntp server {re.escape(ntp_server)}\s*$", ntp_out, re.M),
                    failures,
                )
        except Exception as e:
            failures.append(f"{name}: validation error ({e})")
    # Allow OSPF adjacency to converge before neighbor-state validation.
    time.sleep(40)
    try:
        with ios(devs["rtr01"]["host"], creds) as c:
            c.enable()
            check(
                "rtr01: OSPF neighbor state FULL",
                "FULL" in c.send_command("show ip ospf neighbor"),
                failures,
            )
    except Exception as e:
        failures.append(f"rtr01: OSPF neighbor check error ({e})")

    if failures:
        print("FAILED")
        for item in failures:
            print(f"- {item}")
        sys.exit(1)

    print("OK")
    sys.exit(0)


if __name__ == "__main__":
    main()
