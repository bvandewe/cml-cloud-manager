# Welcome to Your AUTOCOR Workstation

This Ubuntu Desktop has all the tools you need for your lab exercises.

As instructed, please follow the steps below to get started.

## Getting Started

### Python Virtual Environment

- Open a terminal
- Navigate to the `~/Desktop/tasks/` directory (`cd ~/Desktop/tasks/`)
- Activate the Python virtual environment with `source venv/bin/activate`

(This is done automatically by VS Code when you open a terminal there.)

### Ansible Playbook

- Find the Ansible playbook and instructions in the `./ansible` directory (`cd ./ansible`)
- Run the Ansible playbook with the shell script `./run-playbook.sh`
- Find the TODO section in `./group_vars/all.yml` and update it with your solution
- Run the Ansible playbook again to apply your changes

### Python Script

- Find the Python script and inventory in the `./scripts` directory (`cd ./scripts`)
- Run the Python script with `python py_deploy.py -i ./py_inventory.yaml`
- Find the TODO section in `./py_deploy.py` and update it with your solution
- Run the Python script again to apply your changes

### Verification

- Verify your work by checking the output of the Ansible playbook and Python script
- Use the provided `scripts/post_validate.py` script to ensure everything is working as expected

## Desktop Package Contents

**What's installed on this desktop:**

- Chrome (web browser)
- Bruno (API testing tool, very similar to Postman but which works offline)
- VS Code (code editor)
- Terminal (command line)
- Python 3.12 (includes netmiko, ansible, and other libraries)
- Wireshark (network analyzer)
- Remmina (remote desktop)
- File Manager (browse your files)
- And more!
