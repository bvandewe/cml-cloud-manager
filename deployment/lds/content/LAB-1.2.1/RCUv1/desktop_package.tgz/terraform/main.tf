﻿resource "null_resource" "sw01_vlan" {
  provisioner "local-exec" {
    command = "python3 ../scripts/tf_push.py switch --host ${var.sw01_ip} --user ${var.username} --pass ${var.password} --secret ${var.secret} --vlan-id ${var.vlan_id} --vlan-name ${var.vlan_name}"
  }
}
resource "null_resource" "sw02_vlan" {
  provisioner "local-exec" {
    command = "python3 ../scripts/tf_push.py switch --host ${var.sw02_ip} --user ${var.username} --pass ${var.password} --secret ${var.secret} --vlan-id ${var.vlan_id} --vlan-name ${var.vlan_name}"
  }
}
resource "null_resource" "routers_link_ospf_desc" {
  provisioner "local-exec" {
    command = "python3 ../scripts/tf_push.py routers --rtr01 ${var.rtr01_ip} --rtr02 ${var.rtr02_ip} --user ${var.username} --pass ${var.password} --secret ${var.secret} --rtr01-g1 '${var.rtr01_g1_ip}' --rtr02-g1 '${var.rtr02_g1_ip}' --rtr01-desc '${var.rtr01_g1_desc}' --rtr02-desc '${var.rtr02_g1_desc}' --ospf ${var.ospf_process} --area ${var.area} --link-net '10.0.12.0 0.0.0.3'"
  }
}
