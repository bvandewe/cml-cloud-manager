﻿variable "rtr01_ip" { default = "192.168.20.11" }
variable "rtr02_ip" { default = "192.168.20.12" }
variable "sw01_ip"  { default = "192.168.20.21" }
variable "sw02_ip"  { default = "192.168.20.22" }

variable "username" { default = "admin" }
variable "password" { default = "cisco" }
variable "secret"   { default = "cisco" }

variable "rtr01_g1_ip"  { default = "10.0.12.1 255.255.255.252" }
variable "rtr02_g1_ip"  { default = "10.0.12.2 255.255.255.252" }

# TODO: Fill the lab values below.
# Notes:
# - These variables are consumed by terraform/main.tf and passed to scripts/tf_push.py.
# - Keep variable names unchanged (vlan_id, vlan_name, ospf_process, area, rtr01_g1_desc, rtr02_g1_desc).
# Expected outcome for post-validation:
# - VLAN exists on both switches(id 70, name LAB70).
# - Router Gi2 link is configured with descriptions(to-rtr02, to-rtr01).
# - OSPF adjacency forms between rtr01 and rtr02 (process 20, area 0).
