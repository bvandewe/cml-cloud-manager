﻿terraform {
  required_version = ">= 1.1.8"
  required_providers {
    null = { source = "hashicorp/null", version = "~> 3.2" }
  }
}
provider "null" {}
