# Welcome to Your AUTOCOR Workstation

This Ubuntu Desktop has all the tools you need for your lab exercises.

As instructed, please follow the steps below to get started.

## Getting Started

### Python Virtual Environment

- Open a terminal
- Navigate to the `~/Desktop/tasks/` directory (`cd ~/Desktop/tasks/`)
- Activate the Python virtual environment with `source venv/bin/activate`

(This is done automatically by VS Code when you open a terminal there.)

### Terraform Run

- Find the Terraform configuration in the `./terraform` directory (`cd ./terraform`)
- The Terraform provider binary is already in this directory
- Run the `terraform init -plugin-dir=.` command to initialize the working directory
- Find the TODO section in `./variables.tf` and update it with your solution
- Run the `terraform apply` command to apply your changes

### RESTCONF Script

- Find the Python script and inventory in the `./restconf` directory (`cd ./restconf`)
- Find the TODO section in `./model.yaml` and update it with your solution
- Run the Python script with `python restconf_push.py`

### Verification

- Verify your work by checking the output of the Terraform command and Python script
- Use the provided `scripts/post_validate.py` script to ensure everything is working as expected

## Candidate Tasks

- Task 1: Open the variables.tf file in the Desktop/tasks/terraform folder on the desktop and complete the #TODO section in the code.
- Task 2: After completing the #TODO values in variables.tf, go to the terraform directory and run terraform init -plugin-dir=. followed by terraform apply to push the configuration.
- Task 3: Open the model.yaml file in the Desktop/tasks/restconf folder and complete the #TODO section in the code.
- Task 4: After completing the #TODO values in model.yaml, go to the restconf directory and run python restconf_push.py, and confirm it prints Success.
- Task 5: Confirm that the devices have been configured. You can achieve this by navigating to Desktop/tasks/scripts/ and running python post_validate.py

## Desktop Package Contents

**What's installed on this desktop:**

- Chrome (web browser)
- Bruno (API testing tool, very similar to Postman but which works offline)
- VS Code (code editor)
- Terminal (command line)
- Python 3.12 (includes netmiko, ansible, and other libraries)
- Wireshark (network analyzer)
- Remmina (remote desktop)
- File Manager (browse your files)
- And more!
