#!/usr/bin/env python3
import argparse, yaml, requests, urllib3

urllib3.disable_warnings()
HEADERS = {"Content-Type": "application/yang-data+json", "Accept": "application/yang-data+json"}
HOSTS = {"rtr01": "192.168.20.11:443", "rtr02": "192.168.20.12:443"}


def loopback(hostport, auth, ipcidr):
    ip, mask = ipcidr.split("/")
    netmask = "255.255.255.255" if mask == "32" else None
    body = {
        "ietf-interfaces:interface": {
            "name": "Loopback0",
            "type": "iana-if-type:softwareLoopback",
            "enabled": True,
            "ietf-ip:ipv4": {"address": [{"ip": ip, "netmask": netmask}]},
        }
    }
    url = f"https://{hostport}/restconf/data/ietf-interfaces:interfaces/interface=Loopback0"
    r = requests.put(url, json=body, headers=HEADERS, auth=auth, verify=False, timeout=10)
    r.raise_for_status()


def acl(hostport, auth, name, seq, permit):
    body = {
        "Cisco-IOS-XE-acl:standard": {
            "name": name,
            "access-list-seq-rule": [
                {"sequence": int(seq), "permit": {"std-ace": {"ipv4-prefix": permit.split()[0]}}}
            ],
        }
    }
    url = f"https://{hostport}/restconf/data/Cisco-IOS-XE-native:native/ip/access-list/standard={name}"
    r = requests.put(url, json=body, headers=HEADERS, auth=auth, verify=False, timeout=10)
    r.raise_for_status()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-i", "--input", default="model.yaml")
    ap.add_argument("--username", default="admin")
    ap.add_argument("--password", default="cisco")
    a = ap.parse_args()
    data = yaml.safe_load(open(a.input))
    auth = (a.username, a.password)
    for r in ["rtr01", "rtr02"]:
        hostport = HOSTS[r]
        loopback(hostport, auth, data["routers"][r]["loopback0"])
        acl(
            hostport,
            auth,
            data["acl"]["name"],
            data["acl"]["entries"][0]["sequence"],
            data["acl"]["entries"][0]["permit"],
        )
    print("Success")


if __name__ == "__main__":
    main()
