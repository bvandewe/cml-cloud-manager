﻿#!/usr/bin/env python3
import yaml, argparse, re, sys
from pathlib import Path
from netmiko import ConnectHandler


def load(p):
    with Path(p).open(encoding="utf-8-sig") as f:
        d = yaml.safe_load(f)
    return d["devices"], d["credentials"]


def ios(h, c):
    return ConnectHandler(
        device_type="cisco_ios",
        host=h,
        username=c["username"],
        password=c["password"],
        secret=c["secret"],
    )


def main():
    ap = argparse.ArgumentParser()
    default_inventory = Path(__file__).resolve().parent.parent / "inventory.yaml"
    ap.add_argument("-i", "--inventory", default=str(default_inventory))
    a = ap.parse_args()
    dev, creds = load(a.inventory)
    ok = True
    for sw in ["sw01", "sw02"]:
        with ios(dev[sw]["host"], creds) as c:
            c.enable()
            ok &= bool(re.search(r"\n\s*70\s+LAB70\b", "\n" + c.send_command("show vlan brief")))
    with ios(dev["rtr01"]["host"], creds) as c:
        c.enable()
        ok &= "FULL" in c.send_command("show ip ospf neighbor")
    for r, last in [("rtr01", "1"), ("rtr02", "2")]:
        with ios(dev[r]["host"], creds) as c:
            c.enable()
            ok &= bool(
                re.search(
                    rf"10\.255\.71\.{last}.*up\s+up",
                    c.send_command("show ip interface brief | include Loopback0"),
                )
            )
        with ios(dev[r]["host"], creds) as c:
            c.enable()
            ok &= "ip access-list standard MGMTNET" in c.send_command(
                "show run | section access-list"
            )
    print("SUCCESS" if ok else "FAILED")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
