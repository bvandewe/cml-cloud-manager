#!/usr/bin/env python3
import argparse
from netmiko import ConnectHandler


def conn(host, u, p, s):
    return ConnectHandler(device_type="cisco_ios", host=host, username=u, password=p, secret=s)


def do_switch(host, u, p, s, vid, vn):
    with conn(host, u, p, s) as c:
        c.enable()
        c.send_config_set([f"vlan {vid}", f"name {vn}", "exit"])
        c.save_config()


def do_routers(r1, r2, u, p, s, g1, g2, d1, d2, ospf, area, net):
    for host, ip, desc in [(r1, g1, d1), (r2, g2, d2)]:
        with conn(host, u, p, s) as c:
            c.enable()
            c.send_config_set(["no logging console"])
            cmds = [
                "interface GigabitEthernet2",
                f"description {desc}",
                f"ip address {ip}",
                "no shutdown",
                "exit",
            ]
            c.send_config_set(cmds)
            cmds = [f"router ospf {ospf}", f"network {net} area {area}", "exit"]
            c.send_config_set(cmds)
            c.save_config()


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd")
    sw = sub.add_parser("switch")
    sw.add_argument("--host")
    sw.add_argument("--user")
    sw.add_argument("--pass", dest="password")
    sw.add_argument("--secret")
    sw.add_argument("--vlan-id", type=int)
    sw.add_argument("--vlan-name")
    rt = sub.add_parser("routers")
    rt.add_argument("--rtr01")
    rt.add_argument("--rtr02")
    rt.add_argument("--user")
    rt.add_argument("--pass", dest="password")
    rt.add_argument("--secret")
    rt.add_argument("--rtr01-g1")
    rt.add_argument("--rtr02-g1")
    rt.add_argument("--rtr01-desc")
    rt.add_argument("--rtr02-desc")
    rt.add_argument("--ospf", type=int)
    rt.add_argument("--area", type=int)
    rt.add_argument("--link-net")
    a = ap.parse_args()
    if a.cmd == "switch":
        do_switch(a.host, a.user, a.password, a.secret, a.vlan_id, a.vlan_name)
    elif a.cmd == "routers":
        do_routers(
            a.rtr01,
            a.rtr02,
            a.user,
            a.password,
            a.secret,
            a.rtr01_g1,
            a.rtr02_g1,
            a.rtr01_desc,
            a.rtr02_desc,
            a.ospf,
            a.area,
            a.link_net,
        )


if __name__ == "__main__":
    main()
